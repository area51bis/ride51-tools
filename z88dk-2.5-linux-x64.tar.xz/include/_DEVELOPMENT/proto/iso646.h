include(__link__.m4)

#ifndef __ISO646_H__
#define __ISO646_H__

#define and    && 
#define and_eq &= 
#define bitand & 
#define bitor  | 
#define compl  ~ 
#define not    ! 
#define not_eq != 
#define or     || 
#define or_eq  |= 
#define xor    ^ 
#define xor_eq ^= 

#endif
