/* RIDE51's: one tree of headers for DJGPP's and Open Watcom's libraries */
#ifdef __WATCOMC__
#define ALLEGRO_WATCOM
#else
#define ALLEGRO_DJGPP
#endif
